INSTRUCCIONES PARA COMPILAR :

1. Descomprime esta carpeta en tu ordenador.
2. Abre **Visual Studio Code**.
3. Ve a **ARCHIVO -> ABRIR CARPETA...** y selecciona la carpeta **Pokedex_Code**.
4. Asegúrate de tener instalado la extensión **C/C++** de Microsoft.
5. Abre el archivo `main.cpp`.
6. Presiona **Ctrl + Shift + B** para compilar (o usa la terminal integrada escribiendo: `g++ -std=c++11 main.cpp -o pokedex.exe` y luego `./pokedex.exe` en Windows PowerShell).
7. Listo usa el programa. UWU