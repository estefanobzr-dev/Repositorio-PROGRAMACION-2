#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>
#include <iomanip>

using namespace std;

struct Pokemon {
    int id;
    string nombre;
    string tipo1;
    string tipo2;
    int total;
    int hp;
    int ataque;
    int defensa;
    int ataque_esp;
    int defensa_esp;
    int velocidad;
    int generacion;
    bool legendario;
};

string aMinusculas(string str) {
    transform(str.begin(), str.end(), str.begin(), [](unsigned char c) { return tolower(c); });
    return str;
}

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\r\n");
    if (first == string::npos) return "";
    size_t last = str.find_last_not_of(" \t\r\n");
    return str.substr(first, (last - first + 1));
}

void mostrarPokemon(const Pokemon& p) {
    cout << "----------------------------------------" << endl;
    cout << "ID Pokedex:    " << p.id << endl;
    cout << "Nombre:        " << p.nombre << endl;
    cout << "Tipo 1:        " << p.tipo1 << endl;
    cout << "Tipo 2:        " << (p.tipo2.empty() ? "Ninguno" : p.tipo2) << endl;
    cout << "Total Stats:   " << p.total << endl;
    cout << "HP:            " << p.hp << endl;
    cout << "Ataque:        " << p.ataque << endl;
    cout << "Defensa:       " << p.defensa << endl;
    cout << "Ataque Esp.:   " << p.ataque_esp << endl;
    cout << "Defensa Esp.:  " << p.defensa_esp << endl;
    cout << "Velocidad:     " << p.velocidad << endl;
    cout << "Generacion:    " << p.generacion << endl;
    cout << "Es Legendario: " << (p.legendario ? "Si" : "No") << endl;
    cout << "----------------------------------------" << endl;
}

vector<Pokemon> cargarFichero(const string& nombreArchivo) {
    vector<Pokemon> lista;
    ifstream archivo(nombreArchivo);

    if (!archivo.is_open()) {
        cerr << "Error: No se pudo abrir el archivo '" << nombreArchivo << "'." << endl;
        return lista;
    }

    string linea;
    getline(archivo, linea); // Cabecera

    while (getline(archivo, linea)) {
        if (trim(linea).empty()) continue;

        stringstream ss(linea);
        string item;
        Pokemon p;

        getline(ss, item, ','); p.id = stoi(trim(item));
        getline(ss, p.nombre, ','); p.nombre = trim(p.nombre);
        getline(ss, p.tipo1, ','); p.tipo1 = trim(p.tipo1);
        getline(ss, p.tipo2, ','); p.tipo2 = trim(p.tipo2);
        
        getline(ss, item, ','); p.total = stoi(trim(item));
        getline(ss, item, ','); p.hp = stoi(trim(item));
        getline(ss, item, ','); p.ataque = stoi(trim(item));
        getline(ss, item, ','); p.defensa = stoi(trim(item));
        getline(ss, item, ','); p.ataque_esp = stoi(trim(item));
        getline(ss, item, ','); p.defensa_esp = stoi(trim(item));
        getline(ss, item, ','); p.velocidad = stoi(trim(item));
        getline(ss, item, ','); p.generacion = stoi(trim(item));
        
        getline(ss, item, ',');
        item = aMinusculas(trim(item));
        p.legendario = (item == "true" || item == "1");

        lista.push_back(p);
    }

    archivo.close();
    return lista;
}

// 1. Ver info de pokemon por número de Pokedex
void verPorNumero(const vector<Pokemon>& pokemonList) {
    int idBuscado;
    cout << "\nIngrese el numero de Pokedex (ID): ";
    cin >> idBuscado;

    bool encontrado = false;
    for (const auto& p : pokemonList) {
        if (p.id == idBuscado) {
            mostrarPokemon(p);
            encontrado = true;
            break;
        }
    }
    if (!encontrado) {
        cout << "No se encontro ningun Pokemon con el ID " << idBuscado << "." << endl;
    }
}

// 2. Ver info / Buscar pokemon por nombre
void verPorNombre(const vector<Pokemon>& pokemonList) {
    string nombreBuscado;
    cout << "\nIngrese el nombre del Pokemon: ";
    cin >> nombreBuscado;
    string nombreBusqLower = aMinusculas(nombreBuscado);

    bool encontrado = false;
    for (const auto& p : pokemonList) {
        if (aMinusculas(p.nombre) == nombreBusqLower) {
            mostrarPokemon(p);
            encontrado = true;
            break;
        }
    }
    if (!encontrado) {
        cout << "No se encontro ningun Pokemon con el nombre '" << nombreBuscado << "'." << endl;
    }
}

// 3. Ver pokemons de un tipo (seleccionado por el usuario)
void verPorTipo(const vector<Pokemon>& pokemonList) {
    string tipoBuscado;
    cout << "\nIngrese el tipo de Pokemon (ej. Fire, Water, Grass, etc.): ";
    cin >> tipoBuscado;
    string tipoLower = aMinusculas(tipoBuscado);

    cout << "\n--- POKEMON DE TIPO: " << tipoBuscado << " ---" << endl;
    int contador = 0;
    for (const auto& p : pokemonList) {
        if (aMinusculas(p.tipo1) == tipoLower || aMinusculas(p.tipo2) == tipoLower) {
            cout << "ID: " << setw(3) << p.id << " | Nombre: " << setw(12) << p.nombre 
                 << " | Tipo 1: " << setw(8) << p.tipo1 << " | Tipo 2: " << p.tipo2 
                 << " | Total Stats: " << p.total << endl;
            contador++;
        }
    }
    if (contador == 0) {
        cout << "No se encontraron Pokemon con ese tipo." << endl;
    } else {
        cout << "Total encontrados: " << contador << endl;
    }
}

// 4. Ver pokemon con estadísticas más fuertes (top 3) y top débiles
void verTopFuerteDebiles(const vector<Pokemon>& pokemonList) {
    if (pokemonList.empty()) return;

    vector<Pokemon> copia = pokemonList;

    // Ordenar de mayor a menor según el Total de estadísticas
    sort(copia.begin(), copia.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.total > b.total;
    });

    cout << "\n========================================" << endl;
    cout << "    TOP 3 POKEMON MAS FUERTES (STAT TOTAL)" << endl;
    cout << "========================================" << endl;
    for (size_t i = 0; i < 3 && i < copia.size(); ++i) {
        cout << i + 1 << ". " << copia[i].nombre << " (ID: " << copia[i].id << ") - Total: " << copia[i].total << endl;
    }

    cout << "\n========================================" << endl;
    cout << "    TOP 3 POKEMON MAS DEBILES (STAT TOTAL)" << endl;
    cout << "========================================" << endl;
    size_t n = copia.size();
    for (size_t i = 0; i < 3 && i < n; ++i) {
        Pokemon debil = copia[n - 1 - i];
        cout << i + 1 << ". " << debil.nombre << " (ID: " << debil.id << ") - Total: " << debil.total << endl;
    }
}



// 5.ver pokemon con mas stats en cada categoria (HP, Ataque, Defensa, Ataque Especial, Defensa Especial, Velocidad)
void verTopStats(const vector<Pokemon>& pokemonList) {
    if (pokemonList.empty()) return;

    cout << "\n========================================" << endl;
    cout << "    POKEMON CON MAS STATS POR CATEGORIA" << endl;
    cout << "========================================" << endl;

    auto maxHP = max_element(pokemonList.begin(), pokemonList.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.hp < b.hp;
    });
    cout << "HP: " << maxHP->nombre << " (ID: " << maxHP->id << ") - HP: " << maxHP->hp << endl;

    auto maxAtaque = max_element(pokemonList.begin(), pokemonList.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.ataque < b.ataque;
    });
    cout << "Ataque: " << maxAtaque->nombre << " (ID: " << maxAtaque->id << ") - Ataque: " << maxAtaque->ataque << endl;

    auto maxDefensa = max_element(pokemonList.begin(), pokemonList.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.defensa < b.defensa;
    });
    cout << "Defensa: " << maxDefensa->nombre << " (ID: " << maxDefensa->id << ") - Defensa: " << maxDefensa->defensa << endl;

    auto maxAtaqueEspecial = max_element(pokemonList.begin(), pokemonList.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.ataque_esp < b.ataque_esp;
    });
    cout << "Ataque Especial: " << maxAtaqueEspecial->nombre << " (ID: " << maxAtaqueEspecial->id << ") - Ataque Especial: " << maxAtaqueEspecial->ataque_esp << endl;

    auto maxDefensaEspecial = max_element(pokemonList.begin(), pokemonList.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.defensa_esp < b.defensa_esp;
    });
    cout << "Defensa Especial: " << maxDefensaEspecial->nombre << " (ID: " << maxDefensaEspecial->id << ") - Defensa Especial: " << maxDefensaEspecial->defensa_esp << endl;

    auto maxVelocidad = max_element(pokemonList.begin(), pokemonList.end(), [](const Pokemon& a, const Pokemon& b) {
        return a.velocidad < b.velocidad;
    });
    cout << "Velocidad: " << maxVelocidad->nombre << " (ID: " << maxVelocidad->id << ") - Velocidad: " << maxVelocidad->velocidad << endl;
}

int main() {
    string rutaArchivo = "pokemon_151_registros.csv";
    vector<Pokemon> pokedex = cargarFichero(rutaArchivo);

    if (pokedex.empty()) {
        cout << "No se pudieron cargar los datos de la Pokedex." << endl;
        return 1;
    }

    cout << "Pokedex cargada exitosamente con " << pokedex.size() << " registros!" << endl;

    int opcion;
    do {
        cout << "\n========================================" << endl;
        cout << "            MENU POKEDEX                " << endl;
        cout << "========================================" << endl;
        cout << "1. Ver info de Pokemon por numero (ID)" << endl;
        cout << "2. Ver info / Buscar Pokemon por nombre" << endl;
        cout << "3. Ver Pokemon de un tipo especifico" << endl;
        cout << "4. Ver Top 3 mas fuertes y Top 3 mas debiles" << endl;
        cout << "5. Ver Pokemon con mas stats en cada categoria" << endl;
        cout << "6. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1: verPorNumero(pokedex); break;
            case 2: verPorNombre(pokedex); break;
            case 3: verPorTipo(pokedex); break;
            case 4: verTopFuerteDebiles(pokedex); break;
            case 5: verTopStats(pokedex); break;
            case 6: cout << "Saliendo del programa. ¡Hasta luego!" << endl; break;
            default: cout << "Opción inválida. Intente de nuevo." << endl; break;
        }
    } while (opcion != 6);

    return 0;
}
